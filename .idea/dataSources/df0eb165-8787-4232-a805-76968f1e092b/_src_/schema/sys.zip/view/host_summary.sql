CREATE VIEW host_summary AS
  SELECT
    if(isnull(`performance_schema`.`accounts`.`HOST`), 'background', `performance_schema`.`accounts`.`HOST`) AS `host`,
    sum(
        `stmt`.`total`)                                                                                      AS `statements`,
    `sys`.`format_time`(sum(
                            `stmt`.`total_latency`))                                                         AS `statement_latency`,
    `sys`.`format_time`(ifnull((sum(`stmt`.`total_latency`) / nullif(sum(`stmt`.`total`), 0)),
                               0))                                                                           AS `statement_avg_latency`,
    sum(
        `stmt`.`full_scans`)                                                                                 AS `table_scans`,
    sum(
        `io`.`ios`)                                                                                          AS `file_ios`,
    `sys`.`format_time`(sum(
                            `io`.`io_latency`))                                                              AS `file_io_latency`,
    sum(
        `performance_schema`.`accounts`.`CURRENT_CONNECTIONS`)                                               AS `current_connections`,
    sum(
        `performance_schema`.`accounts`.`TOTAL_CONNECTIONS`)                                                 AS `total_connections`,
    count(DISTINCT
          `performance_schema`.`accounts`.`USER`)                                                            AS `unique_users`,
    `sys`.`format_bytes`(sum(
                             `mem`.`current_allocated`))                                                     AS `current_memory`,
    `sys`.`format_bytes`(sum(
                             `mem`.`total_allocated`))                                                       AS `total_memory_allocated`
  FROM (((`performance_schema`.`accounts`
    JOIN `sys`.`x$host_summary_by_statement_latency` `stmt`
      ON ((`performance_schema`.`accounts`.`HOST` = `stmt`.`host`))) JOIN `sys`.`x$host_summary_by_file_io` `io`
      ON ((`performance_schema`.`accounts`.`HOST` = `io`.`host`))) JOIN `sys`.`x$memory_by_host_by_current_bytes` `mem`
      ON ((`performance_schema`.`accounts`.`HOST` = `mem`.`host`)))
  GROUP BY if(isnull(`performance_schema`.`accounts`.`HOST`), 'background', `performance_schema`.`accounts`.`HOST`);
